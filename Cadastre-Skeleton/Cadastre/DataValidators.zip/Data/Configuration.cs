﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server = DESKTOP-QFUL2VE\SQLEXPRESS;Database = Cadastre; Integrated Security = true";
    }
}
